<template>
  <div class="footer"  v-show="bbb">
      <p><span>{{aaa}} items left</span></p>
      <div>
          <span @click="allTodosFn">All</span>
          <span  @click="doneFn">Active</span>
          <span @click="unDoneFn">Completed</span>
      </div>
      <div>
          <span  @click="okFn">Clear completed</span>
      </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
export default {
    name:'Footer',
    data(){
        return {
            todos:[],
            aaa:0,
            bbb:0
        }
    },
    mounted(){
        this.todos = this.$store.state.todos
    },
    computed:{
        ...mapState({length:'todos'}),
    },
    methods:{
        // 全部
        allTodosFn(){
            this.$store.commit('NUM',1)
        },
        // 已完成
        doneFn(){
            this.$store.commit('NUM',2)
        },
        // 未完成
        unDoneFn(){
            this.$store.commit('NUM',3)
        },
        // 清除已完成
        okFn(){
            this.$store.commit('CLEAR')
        }
        
    },
    watch:{
        length:{
            deep:true,
            handler(val){
                this.aaa = val.filter(item=>!item.done).length
                this.bbb = val.length
            }
        }
    }
}
</script>

<style>
.footer{
    display: flex;
    justify-content: space-between;
    background: #fff;
    padding: 10px;
    font-family: 楷体;
}
.footer span{
    color: inherit;
    margin: 3px;
    padding: 3px 7px;
    text-decoration: none;
    border: 1px solid transparent;
    border-radius: 3px;
    cursor: pointer;
}
</style>