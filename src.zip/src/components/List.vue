<template>
  <div>
      <ul>
          <li v-for="item in todosN" :key="item.id" class="li" :style="{textDecoration:item.done?'line-through':''}">
                <input type="checkbox" v-model="item.done">
                <p>{{item.title}}</p>
                <span @click="remove(item.id)" class="sshanchu">x</span>
          </li>
      </ul>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
    name:"List",
    data(){
        return {
            todos:[],
            todosN:[]
        }
    },
    mounted(){
        this.todosN = this.todos = this.$store.state.todos
    },
    computed:{
        ...mapState({num:'num',todos1:'todos'})
    },
    methods:{
        remove(id){
            this.todos = this.todos.filter(item=>item.id !== id)
        }
    },
    watch:{
        num:{
            deep:true,
            handler(val){
                console.log(val)
                if(this.num == 1){
                    this.todosN = this.todos
                }else if(this.num == 2){
                    this.todosN = this.todos.filter(item=>item.done)
                }else if(this.num == 3){
                    this.todosN = this.todos.filter(item=>!item.done)
                }
            }
        },
        todos:{
            deep:true,
            handler(val){
                this.$store.commit('TODOS',val)
                console.log(val)
            }
        },
        todos1:{
            deep:true,
            handler(val){
                this.todosN = this.todos = val
            }
        }
    }
}
</script>

<style scoped>
.check{
    background: url(../assets/下载.svg);
    width: 40px;
    height: 40px;
}
.li{
    background: #fff;
    display: flex;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid rgb(237, 237, 237);
    position: relative;
}
input{
    margin: 0px 20px;
}
.sshanchu{
    display: none;
    position: absolute;
    right:20px;
    padding: 20px;
    cursor: pointer;
}
.li:hover .sshanchu{
    display: block;
}
</style>