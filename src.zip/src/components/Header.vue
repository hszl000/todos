<template>
  <div class="div_ipt">
      <input type="checkbox" @click="checkAll" class="all_ch" ref="ipt">
      <input class="ipt" type="text" v-model="ipt" @keydown.enter="addTodo" placeholder="What needs to be done?">
  </div>
</template>

<script>
import {nanoid} from 'nanoid'
export default {
    name:'Header',
    data(){
        return {
            ipt:''
        }
    },
    methods:{
        addTodo(){
            // 判断为空
            if(this.ipt.trim() == '') return alert('请输入内容')
            // 包装TODO
            let todoObj = {title:this.ipt,done:false,id:nanoid()}
            this.$store.commit('ADDTODO',todoObj)
            this.ipt = ''
        },
        checkAll(e){
            this.$store.commit('ALL',e.target.checked)
        }
    },
}
</script>

<style scoped>
.div_ipt {
    padding: 16px 16px 16px 60px;
    border: none;
    background: rgba(0, 0, 0, 0.003);
    background: #fff;
    margin-bottom: 5px;
    position: relative;
}
.ipt{
    width: 100%;
    height: 30px;
    outline: none;
    border: none;
    background: #fff;
}
.all_ch{
    position: absolute;
    top:26px;
    left:23px;
}
</style>