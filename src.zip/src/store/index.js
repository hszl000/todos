import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    todos:[],
    num:1
  },
  mutations: {
    ADDTODO(state,val){
      state.todos.unshift(val)
    },
    NUM(state,val){
      state.num = val
    },
    TODOS(state,val){
      state.todos = val
    },
    CLEAR(state){
      let obj = state.todos
      state.todos = obj.filter(item=>!item.done)
    },
    ALL(state,val){
      let obj = state.todos
      state.todos = obj.map(item=>item.done = val)
    }
  },
  actions: {
  },
  modules: {
  },
  getters: {
		doneTodos: state => {
		  return state.todos.filter(todo => todo.done)
		},
		unDoneTodos: (_, getters) => {
    		return getters.todos.length
  	}
	}
})
